import React, { useState, useMemo, useEffect, useCallback } from "react";
import { MapPin, Calendar, Clock, Plus, Check, StickyNote, Users2, Trash2, ChevronDown, ChevronUp, RefreshCw } from "lucide-react";
import { doc, getDoc, setDoc, onSnapshot } from "firebase/firestore";
import { db } from "./firebase";

const FRIENDS = [
  { name: "ปานดา", color: "#E2836B" },
  { name: "นัท", color: "#7C9473" },
  { name: "พิมพ์", color: "#D9A441" },
  { name: "ใหม่", color: "#8B98B8" },
  { name: "ปูเป้", color: "#C97B9A" },
  { name: "มิ้น", color: "#6FA88A" },
  { name: "เหมย", color: "#CE8F5C" },
  { name: "แสนดี", color: "#9B8AA6" },
  { name: "มิก", color: "#7395A8" },
  { name: "จูเนียร์", color: "#B5824A" },
];

const TRIPS_DOC = doc(db, "kobbee-trips", "shared");

const defaultTrips = [
  {
    id: 1,
    destination: "เขาใหญ่ ชมทะเลหมอก",
    date: "2026-08-22",
    time: "06:00",
    note: "นัดจอดรถปั๊มขาเข้า พกเสื้อกันหนาวมาด้วยนะ",
    creator: "ปานดา",
    rsvps: ["ปานดา", "มิ้น", "นัท"],
  },
  {
    id: 2,
    destination: "คาเฟ่ใหม่ย่านทองหล่อ",
    date: "2026-08-15",
    time: "17:30",
    note: "งบกันเอง คนละ ~300 บาท",
    creator: "พิมพ์",
    rsvps: ["พิมพ์"],
  },
];

function initials(name) {
  return name.slice(0, 1);
}

function formatThaiDate(dateStr) {
  if (!dateStr) return "";
  const d = new Date(dateStr + "T00:00:00");
  return d.toLocaleDateString("th-TH-u-ca-gregory", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

export default function TripScheduler() {
  const [trips, setTrips] = useState([]);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [loadError, setLoadError] = useState(false);
  const [form, setForm] = useState({
    destination: "",
    date: "",
    time: "",
    note: "",
    creator: FRIENDS[0].name,
  });
  const [formOpen, setFormOpen] = useState(false);
  const [confirmDeleteId, setConfirmDeleteId] = useState(null);
  const [showPast, setShowPast] = useState(false);

  const loadTrips = useCallback(async () => {
    setLoading(true);
    try {
      const snap = await getDoc(TRIPS_DOC);
      if (snap.exists()) {
        setTrips(snap.data().trips || []);
      } else {
        // first time ever opened — seed with example trips
        await setDoc(TRIPS_DOC, { trips: defaultTrips });
        setTrips(defaultTrips);
      }
      setLoadError(false);
    } catch (err) {
      console.error("Load error:", err);
      setLoadError(true);
      setTrips(defaultTrips);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadTrips();
    // ฟังการเปลี่ยนแปลงแบบเรียลไทม์ — เพื่อนเพิ่ม/แก้ทริป จะขึ้นให้ทุกคนเห็นทันทีโดยไม่ต้องกดรีเฟรช
    const unsubscribe = onSnapshot(
      TRIPS_DOC,
      (snap) => {
        if (snap.exists()) {
          setTrips(snap.data().trips || []);
          setLoadError(false);
        }
      },
      (err) => {
        console.error("Realtime sync error:", err);
        setLoadError(true);
      }
    );
    return () => unsubscribe();
  }, [loadTrips]);

  async function persistTrips(nextTrips) {
    setTrips(nextTrips);
    setSyncing(true);
    try {
      await setDoc(TRIPS_DOC, { trips: nextTrips });
    } catch (err) {
      console.error("Save error:", err);
    } finally {
      setSyncing(false);
    }
  }

  const todayStr = useMemo(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
      d.getDate()
    ).padStart(2, "0")}`;
  }, []);

  const { upcomingTrips, pastTrips } = useMemo(() => {
    const sorted = [...trips].sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
    return {
      upcomingTrips: sorted.filter((t) => t.date >= todayStr),
      pastTrips: sorted.filter((t) => t.date < todayStr).reverse(),
    };
  }, [trips, todayStr]);

  function deleteTrip(id) {
    if (confirmDeleteId === id) {
      persistTrips(trips.filter((t) => t.id !== id));
      setConfirmDeleteId(null);
    } else {
      setConfirmDeleteId(id);
    }
  }

  function handleSubmit(e) {
    e.preventDefault();
    if (!form.destination || !form.date) return;
    const newTrip = {
      id: Date.now(),
      destination: form.destination,
      date: form.date,
      time: form.time,
      note: form.note,
      creator: form.creator,
      rsvps: [form.creator],
    };
    persistTrips([...trips, newTrip]);
    setForm({ destination: "", date: "", time: "", note: "", creator: FRIENDS[0].name });
    setFormOpen(false);
  }

  function toggleRsvp(tripId, name) {
    const next = trips.map((t) => {
      if (t.id !== tripId) return t;
      const going = t.rsvps.includes(name);
      return {
        ...t,
        rsvps: going ? t.rsvps.filter((n) => n !== name) : [...t.rsvps, name],
      };
    });
    persistTrips(next);
  }

  if (loading) {
    return (
      <div
        style={{
          minHeight: "100vh",
          background: "#F2EEE3",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          gap: "0.75rem",
          fontFamily: "'Sarabun', sans-serif",
          color: "#8A8375",
        }}
      >
        <style>{`
          @import url('https://fonts.googleapis.com/css2?family=Kanit:wght@600;700&family=Sarabun:wght@400;500&display=swap');
          @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        `}</style>
        <RefreshCw size={28} color="#7C9473" style={{ animation: "spin 1s linear infinite" }} />
        <p style={{ fontSize: "0.9rem" }}>กำลังโหลดข้อมูลทริป...</p>
      </div>
    );
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#F2EEE3",
        fontFamily: "'Sarabun', sans-serif",
        color: "#3A3530",
        paddingBottom: "4rem",
      }}
    >
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Kanit:wght@500;600;700&family=Sarabun:wght@400;500;600&display=swap');
        .kanit { font-family: 'Kanit', sans-serif; }
        .ticket-notch {
          position: absolute;
          width: 22px;
          height: 22px;
          background: #F2EEE3;
          border-radius: 999px;
          top: 50%;
          transform: translateY(-50%);
        }
        .chip {
          transition: all 0.15s ease;
        }
        .chip:active {
          transform: scale(0.95);
        }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>

      {/* Header */}
      <div
        style={{
          background: "linear-gradient(135deg, #7C9473 0%, #6FA88A 100%)",
          padding: "2.5rem 1.25rem 1.75rem",
          position: "relative",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            position: "absolute",
            right: "-30px",
            top: "-30px",
            width: "160px",
            height: "160px",
            borderRadius: "999px",
            background: "rgba(255,255,255,0.08)",
          }}
        />
        <button
          onClick={loadTrips}
          title="รีเฟรชข้อมูลล่าสุด"
          style={{
            position: "absolute",
            top: "1.1rem",
            right: "1.1rem",
            width: "34px",
            height: "34px",
            borderRadius: "999px",
            border: "none",
            background: "rgba(255,255,255,0.18)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            cursor: "pointer",
            zIndex: 2,
          }}
        >
          <RefreshCw size={16} color="#FFFDF8" style={syncing ? { animation: "spin 0.8s linear infinite" } : {}} />
        </button>
        <p
          className="kanit"
          style={{
            color: "#EFEAD8",
            fontSize: "0.8rem",
            letterSpacing: "0.15em",
            fontWeight: 500,
            marginBottom: "0.35rem",
          }}
        >
          กลุ่มเพื่อนสิบคน
        </p>
        <h1
          className="kanit"
          style={{
            color: "#FFFDF8",
            fontSize: "1.9rem",
            fontWeight: 700,
            margin: 0,
            lineHeight: 1.3,
          }}
        >
          นัดเพื่อนเที่ยว 🌿
        </h1>
      </div>

      {loadError && (
        <div style={{ margin: "0.75rem 1rem 0", padding: "0.6rem 0.9rem", background: "#F6D9CE", borderRadius: "10px", fontSize: "0.78rem", color: "#8A4A34" }}>
          โหลดข้อมูลล่าสุดไม่สำเร็จ กำลังแสดงข้อมูลตัวอย่างไว้ก่อน ลองกดปุ่มรีเฟรชอีกครั้ง
        </div>
      )}
      <div style={{ padding: "0 1rem", marginTop: "1.1rem", position: "relative", zIndex: 1 }}>
        <div
          style={{
            background: "#FFFDF8",
            borderRadius: "18px",
            boxShadow: "0 8px 24px rgba(58,53,48,0.12)",
            border: "1px solid #E4DFCF",
            overflow: "hidden",
          }}
        >
          {!formOpen ? (
            <button
              onClick={() => setFormOpen(true)}
              className="kanit"
              style={{
                width: "100%",
                padding: "1.1rem",
                background: "transparent",
                border: "none",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: "0.5rem",
                fontSize: "1rem",
                fontWeight: 600,
                color: "#E2836B",
                cursor: "pointer",
              }}
            >
              <Plus size={20} strokeWidth={2.5} />
              สร้างนัดทริปใหม่
            </button>
          ) : (
            <form onSubmit={handleSubmit} style={{ padding: "1.25rem" }}>
              <h2
                className="kanit"
                style={{ fontSize: "1.1rem", fontWeight: 600, marginBottom: "1rem" }}
              >
                รายละเอียดทริป
              </h2>

              <label style={labelStyle}>สถานที่อยากไป</label>
              <input
                style={inputStyle}
                placeholder="เช่น เขาใหญ่, ตลาดนัดจตุจักร"
                value={form.destination}
                onChange={(e) => setForm({ ...form, destination: e.target.value })}
                required
              />

              <div style={{ display: "flex", gap: "0.75rem" }}>
                <div style={{ flex: 1 }}>
                  <label style={labelStyle}>วันที่</label>
                  <input
                    type="date"
                    style={inputStyle}
                    value={form.date}
                    onChange={(e) => setForm({ ...form, date: e.target.value })}
                    required
                  />
                </div>
                <div style={{ flex: 1 }}>
                  <label style={labelStyle}>เวลา</label>
                  <input
                    type="time"
                    style={inputStyle}
                    value={form.time}
                    onChange={(e) => setForm({ ...form, time: e.target.value })}
                  />
                </div>
              </div>

              <label style={labelStyle}>โน้ตเพิ่มเติม</label>
              <textarea
                style={{ ...inputStyle, minHeight: "60px", resize: "vertical" }}
                placeholder="รายละเอียด, งบประมาณ..."
                value={form.note}
                onChange={(e) => setForm({ ...form, note: e.target.value })}
              />

              <label style={labelStyle}>คนสร้างนัด</label>
              <div style={{ display: "flex", flexWrap: "wrap", gap: "0.4rem", marginBottom: "1.1rem" }}>
                {FRIENDS.map((f) => (
                  <button
                    type="button"
                    key={f.name}
                    onClick={() => setForm({ ...form, creator: f.name })}
                    className="chip kanit"
                    style={{
                      padding: "0.35rem 0.7rem",
                      borderRadius: "999px",
                      fontSize: "0.8rem",
                      fontWeight: 500,
                      border: form.creator === f.name ? `2px solid ${f.color}` : "1px solid #E4DFCF",
                      background: form.creator === f.name ? `${f.color}22` : "#FFFDF8",
                      color: form.creator === f.name ? f.color : "#8A8375",
                      cursor: "pointer",
                    }}
                  >
                    {f.name}
                  </button>
                ))}
              </div>

              <div style={{ display: "flex", gap: "0.6rem" }}>
                <button
                  type="button"
                  onClick={() => setFormOpen(false)}
                  className="kanit"
                  style={{
                    flex: 1,
                    padding: "0.75rem",
                    borderRadius: "12px",
                    border: "1px solid #E4DFCF",
                    background: "#FFFDF8",
                    color: "#8A8375",
                    fontWeight: 600,
                    cursor: "pointer",
                  }}
                >
                  ยกเลิก
                </button>
                <button
                  type="submit"
                  className="kanit"
                  style={{
                    flex: 2,
                    padding: "0.75rem",
                    borderRadius: "12px",
                    border: "none",
                    background: "#7C9473",
                    color: "#FFFDF8",
                    fontWeight: 600,
                    cursor: "pointer",
                  }}
                >
                  ประกาศนัดเที่ยว
                </button>
              </div>
            </form>
          )}
        </div>
      </div>

      {/* Feed */}
      <div style={{ padding: "1.75rem 1rem 0", display: "flex", flexDirection: "column", gap: "1.25rem" }}>
        {upcomingTrips.map((trip) => renderTripCard(trip))}

        {upcomingTrips.length === 0 && pastTrips.length === 0 && (
          <div style={{ textAlign: "center", padding: "3rem 1rem", color: "#B4AE9E" }}>
            ยังไม่มีทริปที่นัดไว้ กดปุ่มด้านบนเพื่อสร้างทริปแรก
          </div>
        )}

        {upcomingTrips.length === 0 && pastTrips.length > 0 && (
          <div style={{ textAlign: "center", padding: "1.5rem 1rem", color: "#B4AE9E", fontSize: "0.85rem" }}>
            ไม่มีทริปที่กำลังจะถึง 🌤️
          </div>
        )}

        {pastTrips.length > 0 && (
          <div style={{ marginTop: "0.5rem" }}>
            <button
              onClick={() => setShowPast((s) => !s)}
              className="kanit"
              style={{
                width: "100%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: "0.4rem",
                padding: "0.7rem",
                background: "transparent",
                border: "1px dashed #C9C2AE",
                borderRadius: "12px",
                color: "#8A8375",
                fontSize: "0.85rem",
                fontWeight: 600,
                cursor: "pointer",
              }}
            >
              {showPast ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
              ทริปที่ผ่านมาแล้ว ({pastTrips.length})
            </button>

            {showPast && (
              <div style={{ display: "flex", flexDirection: "column", gap: "1rem", marginTop: "1rem", opacity: 0.65 }}>
                {pastTrips.map((trip) => renderTripCard(trip, true))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );

  function renderTripCard(trip, isPast) {
    const going = trip.rsvps;
          const notGoing = FRIENDS.map((f) => f.name).filter((n) => !going.includes(n));
          const creatorColor = FRIENDS.find((f) => f.name === trip.creator)?.color || "#7C9473";

          return (
            <div
              key={trip.id}
              style={{
                background: "#FFFDF8",
                borderRadius: "18px",
                boxShadow: "0 6px 18px rgba(58,53,48,0.09)",
                border: "1px solid #E4DFCF",
                position: "relative",
                overflow: "hidden",
              }}
            >
              {/* washi tape corner */}
              <div
                style={{
                  position: "absolute",
                  top: "-8px",
                  left: "18px",
                  width: "54px",
                  height: "20px",
                  background: `${creatorColor}55`,
                  transform: "rotate(-6deg)",
                  borderRadius: "2px",
                }}
              />

              {/* delete button */}
              <button
                onClick={() => deleteTrip(trip.id)}
                title={confirmDeleteId === trip.id ? "กดอีกครั้งเพื่อยืนยันลบ" : "ลบทริปนี้"}
                style={{
                  position: "absolute",
                  top: "0.9rem",
                  right: "0.9rem",
                  display: "flex",
                  alignItems: "center",
                  gap: "0.25rem",
                  padding: confirmDeleteId === trip.id ? "0.3rem 0.6rem" : "0.4rem",
                  borderRadius: "999px",
                  border: "none",
                  background: confirmDeleteId === trip.id ? "#E2836B" : "#F7F4EC",
                  color: confirmDeleteId === trip.id ? "#FFFDF8" : "#B4AE9E",
                  fontSize: "0.72rem",
                  fontWeight: 600,
                  cursor: "pointer",
                  zIndex: 2,
                }}
                className="kanit"
              >
                <Trash2 size={13} />
                {confirmDeleteId === trip.id && "ยืนยันลบ?"}
              </button>

              <div style={{ padding: "1.4rem 1.25rem 1.1rem" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "0.4rem", marginBottom: "0.3rem", paddingRight: "3.5rem" }}>
                  <MapPin size={16} color="#E2836B" />
                  <h3 className="kanit" style={{ fontSize: "1.15rem", fontWeight: 600, margin: 0 }}>
                    {trip.destination}
                  </h3>
                </div>

                <div style={{ display: "flex", gap: "1rem", fontSize: "0.85rem", color: "#8A8375", marginBottom: "0.6rem" }}>
                  <span style={{ display: "flex", alignItems: "center", gap: "0.3rem" }}>
                    <Calendar size={14} /> {formatThaiDate(trip.date)}
                  </span>
                  {trip.time && (
                    <span style={{ display: "flex", alignItems: "center", gap: "0.3rem" }}>
                      <Clock size={14} /> {trip.time} น.
                    </span>
                  )}
                </div>

                {trip.note && (
                  <div
                    style={{
                      display: "flex",
                      gap: "0.4rem",
                      fontSize: "0.85rem",
                      color: "#6B6558",
                      background: "#F7F4EC",
                      borderRadius: "10px",
                      padding: "0.5rem 0.65rem",
                      marginBottom: "0.5rem",
                    }}
                  >
                    <StickyNote size={14} style={{ flexShrink: 0, marginTop: "2px" }} />
                    <span>{trip.note}</span>
                  </div>
                )}

                <div
                  style={{
                    fontSize: "0.75rem",
                    color: creatorColor,
                    fontWeight: 600,
                  }}
                  className="kanit"
                >
                  จัดโดย {trip.creator}
                </div>
              </div>

              {/* ticket divider */}
              <div style={{ position: "relative", height: "1px", background: "repeating-linear-gradient(to right, #E4DFCF 0 6px, transparent 6px 12px)" }}>
                <div className="ticket-notch" style={{ left: "-11px" }} />
                <div className="ticket-notch" style={{ right: "-11px" }} />
              </div>

              <div style={{ padding: "1rem 1.25rem 1.25rem" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "0.4rem", marginBottom: "0.6rem" }}>
                  <Users2 size={15} color="#7C9473" />
                  <span className="kanit" style={{ fontSize: "0.85rem", fontWeight: 600, color: "#3A3530" }}>
                    ว่างไปแล้ว {going.length} คน
                  </span>
                  {going.length > 0 && (
                    <span style={{ fontSize: "0.78rem", color: "#8A8375" }}>
                      : {going.join(", ")}
                    </span>
                  )}
                </div>

                <div style={{ display: "flex", flexWrap: "wrap", gap: "0.4rem" }}>
                  {FRIENDS.map((f) => {
                    const isGoing = going.includes(f.name);
                    return (
                      <button
                        key={f.name}
                        onClick={() => toggleRsvp(trip.id, f.name)}
                        className="chip kanit"
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: "0.3rem",
                          padding: "0.35rem 0.65rem",
                          borderRadius: "999px",
                          fontSize: "0.78rem",
                          fontWeight: 500,
                          border: isGoing ? `1.5px solid ${f.color}` : "1px solid #E4DFCF",
                          background: isGoing ? f.color : "#FFFDF8",
                          color: isGoing ? "#FFFDF8" : "#8A8375",
                          cursor: "pointer",
                        }}
                      >
                        {isGoing && <Check size={12} strokeWidth={3} />}
                        {f.name}
                      </button>
                    );
                  })}
                </div>

                {notGoing.length > 0 && (
                  <p style={{ fontSize: "0.72rem", color: "#B4AE9E", marginTop: "0.6rem", marginBottom: 0 }}>
                    ยังไม่ตอบรับ: {notGoing.join(", ")}
                  </p>
                )}
              </div>
            </div>
          );
  }
}

const labelStyle = {
  display: "block",
  fontSize: "0.78rem",
  fontWeight: 600,
  color: "#8A8375",
  marginBottom: "0.3rem",
  marginTop: "0.7rem",
};

const inputStyle = {
  width: "100%",
  padding: "0.65rem 0.8rem",
  borderRadius: "10px",
  border: "1px solid #E4DFCF",
  background: "#FCFAF6",
  fontSize: "0.9rem",
  fontFamily: "'Sarabun', sans-serif",
  color: "#3A3530",
  boxSizing: "border-box",
  outline: "none",
};
